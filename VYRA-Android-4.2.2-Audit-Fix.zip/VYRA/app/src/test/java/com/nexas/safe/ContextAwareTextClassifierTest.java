package com.nexas.safe;

import org.junit.Test;
import java.util.Set;
import static org.junit.Assert.*;

public class ContextAwareTextClassifierTest {
    private final Set<String> defaults = Set.of("porn video", "porn videos", "hentai video", "hentai gallery", "nude gallery", "explicit photo gallery");

    @Test public void newsArticleMentionIsNotBlocked() {
        String text = "Breaking news: a court report discusses pornography policy and legal education. "
                + "This research article covers prevention, public policy and law. ".repeat(5);
        assertFalse(ContextAwareTextClassifier.shouldBlock(text, defaults));
    }

    @Test public void medicalEducationMentionIsNotBlocked() {
        String text = "Medical health research and clinical education report: a study reviews pornography policy and patient awareness. "
                + "Doctors and universities discuss prevention and public health guidance. ".repeat(3);
        assertFalse(ContextAwareTextClassifier.shouldBlock(text, defaults));
    }

    @Test public void explicitPhraseIsBlocked() {
        assertTrue(ContextAwareTextClassifier.shouldBlock("watch porn videos now", defaults));
    }

    @Test public void genericAdultTermAloneIsNotBlocked() {
        assertFalse(ContextAwareTextClassifier.shouldBlock("adult learning and adult education resources", defaults));
    }

    @Test public void singlePornographyMentionWithoutContextIsNotEnough() {
        assertFalse(ContextAwareTextClassifier.shouldBlock("A public discussion about pornography policy is scheduled.", defaults));
    }

    @Test public void relatedPornWordFormsDoNotCountAsIndependentSignals() {
        assertFalse(ContextAwareTextClassifier.shouldBlock("The article discusses pornography and pornographic media policy.", defaults));
    }

    @Test public void multipleExplicitSignalsAreBlocked() {
        assertTrue(ContextAwareTextClassifier.shouldBlock("nude and erotic explicit gallery", defaults));
    }

    @Test public void clearExplicitPhraseOverridesContext() {
        assertTrue(ContextAwareTextClassifier.shouldBlock("A news page embeds a link to a free porn video gallery.", defaults));
    }
}
