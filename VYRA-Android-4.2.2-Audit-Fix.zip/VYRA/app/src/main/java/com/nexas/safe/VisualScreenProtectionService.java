package com.nexas.safe;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;
import android.content.pm.ServiceInfo;

import java.io.File;
import java.nio.ByteBuffer;

/**
 * Opt-in, local-only image screening. It starts only with a fresh Android MediaProjection
 * consent result and displays an ongoing notification with a Stop action. Captured frames
 * are held in memory, classified, then recycled; frames are never written or uploaded.
 */
public final class VisualScreenProtectionService extends Service {
    public static final String ACTION_STOP = "com.nexas.safe.action.STOP_VISUAL_SCAN";
    public static final String ACTION_VISUAL_DETECTED = "com.nexas.safe.action.VISUAL_CONTENT_DETECTED";
    public static final String EXTRA_RESULT_CODE = "projection_result_code";
    public static final String EXTRA_RESULT_DATA = "projection_result_data";
    private static final String CHANNEL_ID = "vyra_visual_protection";
    private static final int NOTIFICATION_ID = 4107;
    private static final long FRAME_INTERVAL_MS = 400L;
    private static final long DETECTION_COOLDOWN_MS = 5000L;

    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private HandlerThread workerThread;
    private Handler worker;
    private ImageSafetyClassifier classifier;
    private long lastInferenceAt;
    private long lastDetectionAt;
    private boolean cleaned;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }
        if (ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (projection != null) return START_NOT_STICKY;
        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent resultData;
        if (Build.VERSION.SDK_INT >= 33) resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
        else resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
        if (resultCode == 0 || resultData == null || !ModelManager.isReady(this)) {
            ProtectionPrefs.prefs(this).edit().putBoolean(ProtectionPrefs.KEY_VISUAL_SCAN_ACTIVE, false)
                    .putString(ProtectionPrefs.KEY_VISUAL_SCAN_ERROR, "Screen permission or on-device model is unavailable.").apply();
            stopSelf();
            return START_NOT_STICKY;
        }

        try {
            Notification notification = buildNotification();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                startForeground(NOTIFICATION_ID, notification);
            }
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(resultCode, resultData);
            if (projection == null) throw new IllegalStateException("Android did not create a screen-capture session.");

            workerThread = new HandlerThread("VYRA-Visual-Classifier");
            workerThread.start();
            worker = new Handler(workerThread.getLooper());
            classifier = new ImageSafetyClassifier(ModelManager.modelFile(this));
            startProjectionDisplay();
            ProtectionPrefs.prefs(this).edit().putBoolean(ProtectionPrefs.KEY_VISUAL_SCAN_ACTIVE, true)
                    .remove(ProtectionPrefs.KEY_VISUAL_SCAN_ERROR).apply();
        } catch (Exception ex) {
            ProtectionPrefs.prefs(this).edit().putBoolean(ProtectionPrefs.KEY_VISUAL_SCAN_ACTIVE, false)
                    .putString(ProtectionPrefs.KEY_VISUAL_SCAN_ERROR,
                            ex.getMessage() == null ? "Could not start visual protection." : ex.getMessage()).apply();
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void startProjectionDisplay() {
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        DisplayMetrics metrics = new DisplayMetrics();
        display.getRealMetrics(metrics);
        int width = Math.max(1, metrics.widthPixels);
        int height = Math.max(1, metrics.heightPixels);
        int density = Math.max(1, metrics.densityDpi);

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        imageReader.setOnImageAvailableListener(this::onImageAvailable, worker);
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() {
                stopSelf();
            }
        }, worker);
        virtualDisplay = projection.createVirtualDisplay("VYRA live visual protection", width, height,
                density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(), null, worker);
        if (virtualDisplay == null) throw new IllegalStateException("Android could not create the screen frame stream.");
    }

    private void onImageAvailable(ImageReader reader) {
        Image image = null;
        Bitmap bitmap = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null) return;
            long now = SystemClock.elapsedRealtime();
            if (now - lastInferenceAt < FRAME_INTERVAL_MS) return;
            lastInferenceAt = now;

            // Avoid reclassifying VYRA's own screens and Android system UI.
            String foreground = ProtectionPrefs.prefs(this).getString(ProtectionPrefs.KEY_CURRENT_PACKAGE, "");
            if (getPackageName().equals(foreground) || "com.android.systemui".equals(foreground)
                    || "com.android.permissioncontroller".equals(foreground)) return;

            Image.Plane[] planes = image.getPlanes();
            if (planes == null || planes.length == 0) return;
            Image.Plane plane = planes[0];
            int width = image.getWidth();
            int height = image.getHeight();
            int pixelStride = plane.getPixelStride();
            int rowStride = plane.getRowStride();
            int paddedWidth = Math.max(width, rowStride / Math.max(1, pixelStride));
            ByteBuffer buffer = plane.getBuffer();
            Bitmap padded = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888);
            buffer.rewind();
            padded.copyPixelsFromBuffer(buffer);
            if (paddedWidth == width) {
                bitmap = padded;
            } else {
                bitmap = Bitmap.createBitmap(padded, 0, 0, width, height);
                padded.recycle();
            }

            ImageSafetyClassifier.Result result = classifier.classify(bitmap);
            if (result.flagged && now - lastDetectionAt > DETECTION_COOLDOWN_MS) {
                lastDetectionAt = now;
                Intent detected = new Intent(ACTION_VISUAL_DETECTED).setPackage(getPackageName());
                detected.putExtra("confidence", result.confidence);
                sendBroadcast(detected);
            }
        } catch (Exception ignored) {
            // A single malformed frame should not crash the protection service.
        } finally {
            if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            if (image != null) image.close();
        }
    }

    private Notification buildNotification() {
        Intent stopIntent = new Intent(this, VisualScreenProtectionService.class).setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 4108, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent openIntent = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPending = PendingIntent.getActivity(this, 4109, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("VYRA visual protection is active")
                .setContentText("Screen frames are checked on-device only. Tap Stop to end capture.")
                .setCategory(Notification.CATEGORY_SERVICE)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .setOngoing(true)
                .setContentIntent(openPending)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,
                        "Stop protection", stopPending).build())
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "VYRA visual protection", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Persistent status for user-started on-device screen scanning.");
            channel.setShowBadge(false);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    @Override public void onDestroy() {
        cleanup();
        ProtectionPrefs.prefs(this).edit().putBoolean(ProtectionPrefs.KEY_VISUAL_SCAN_ACTIVE, false).apply();
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE); else stopForeground(true);
        super.onDestroy();
    }

    private void cleanup() {
        if (cleaned) return;
        cleaned = true;
        if (imageReader != null) { imageReader.setOnImageAvailableListener(null, null); imageReader.close(); imageReader = null; }
        if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; }
        if (projection != null) { projection.stop(); projection = null; }
        if (classifier != null) { classifier.close(); classifier = null; }
        if (workerThread != null) { workerThread.quitSafely(); workerThread = null; }
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
