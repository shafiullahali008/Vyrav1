package com.nexas.safe;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.Locale;

/** Offline command-style guide. Responses are local rules/templates; no cloud AI is used. */
public class VyraGuideActivity extends Activity {
    private static final int BG = Color.rgb(7, 10, 19);
    private static final int CARD = Color.rgb(17, 25, 42);
    private static final int WHITE = Color.rgb(240, 245, 255);
    private static final int MUTED = Color.rgb(150, 167, 194);
    private static final int TEAL = Color.rgb(90, 239, 213);
    private static final int VIOLET = Color.rgb(161, 133, 255);
    private LinearLayout messages;
    private EditText input;
    private ScrollView scroll;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(14));
        root.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView mark = label("V", 20, WHITE, true);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(gradient(new int[]{TEAL, VIOLET}, 15));
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(dp(44), dp(44));
        mlp.rightMargin = dp(12);
        header.addView(mark, mlp);
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(label("VYRA GUIDE", 14, WHITE, true));
        TextView offline = label("OFFLINE  •  ON THIS DEVICE", 9, TEAL, true);
        LinearLayout.LayoutParams olp = new LinearLayout.LayoutParams(-2, -2); olp.topMargin = dp(3); titles.addView(offline, olp);
        header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1f));
        Button close = new Button(this); close.setText("×"); close.setTextSize(25); close.setTextColor(WHITE); close.setAllCaps(false);
        close.setBackground(round(CARD, 14)); close.setOnClickListener(v -> finish());
        header.addView(close, new LinearLayout.LayoutParams(dp(46), dp(46)));
        root.addView(header);

        TextView notice = label("This is a lightweight offline guide, not a cloud chatbot or full language model. Your messages are processed locally and are not uploaded.", 11, MUTED, false);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-1, -2); nlp.topMargin = dp(16); nlp.bottomMargin = dp(12); root.addView(notice, nlp);

        scroll = new ScrollView(this); scroll.setFillViewport(false); scroll.setVerticalScrollBarEnabled(false);
        messages = new LinearLayout(this); messages.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(messages, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        addMessage("Hi. I work offline. Ask about Focus Journey, app protection, scanning privacy, games, permissions or settings.", false);

        LinearLayout composer = new LinearLayout(this); composer.setGravity(Gravity.CENTER_VERTICAL);
        composer.setPadding(dp(10), dp(5), dp(5), dp(5)); composer.setBackground(round(CARD, 18));
        input = new EditText(this); input.setSingleLine(true); input.setTextColor(WHITE); input.setHintTextColor(MUTED);
        input.setHint("Ask VYRA Guide…"); input.setTextSize(14); input.setBackgroundColor(Color.TRANSPARENT); input.setPadding(dp(8), 0, dp(5), 0);
        composer.addView(input, new LinearLayout.LayoutParams(0, dp(48), 1f));
        Button send = new Button(this); send.setText("SEND"); send.setTextColor(BG); send.setTextSize(11); send.setTypeface(Typeface.DEFAULT, Typeface.BOLD); send.setAllCaps(false);
        send.setBackground(gradient(new int[]{TEAL, VIOLET}, 13));
        composer.addView(send, new LinearLayout.LayoutParams(dp(74), dp(44)));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, -2); clp.topMargin = dp(12); root.addView(composer, clp);
        send.setOnClickListener(v -> submit());
        input.setOnEditorActionListener((view, action, event) -> { submit(); return true; });
        setContentView(root);
    }

    private void submit() {
        String question = input.getText().toString().trim();
        if (question.isEmpty()) return;
        addMessage(question, true);
        input.setText("");
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(), 0);
        addMessage(answer(question), false);
    }

    private String answer(String question) {
        String q = question.toLowerCase(Locale.ROOT);
        if (has(q, "journey", "streak", "years", "months", "days"))
            return "Open Focus → Long-term Journey. Start it once and the saved start timestamp continues across restarts and reboots. The counter shows calendar years, months, days and time. End it only when you choose to stop.";
        if (has(q, "block", "protection", "accessibility", "apps"))
            return "Open Focus → Choose Apps to Block, select the apps, then enable VYRA Protection in Android Accessibility settings. The service can only act on text and app events Android exposes; some apps do not expose page text.";
        if (has(q, "scan", "record", "recording", "screenshot", "privacy"))
            return "VYRA's automatic page-text checks do not use screen recording or screenshots. They inspect text exposed through the Accessibility permission. You can manually choose an image for a local visual scan when the model is installed.";
        if (has(q, "game", "games", "arcade", "temple", "orbit", "runner"))
            return "Open Games for Temple Sprint 3D and Orbit Roll 3D. They are offline OpenGL ES prototypes with procedural graphics, not console-grade 4K releases. The smaller memory, logic and reaction games are also available.";
        if (has(q, "ai", "assistant", "model", "offline"))
            return "This guide itself uses local rules and prepared responses; it is not a full generative AI model. A real offline language model requires separately licensed weights, enough device memory and performance testing.";
        if (has(q, "uninstall", "delete", "remove", "admin"))
            return "Optional Device Admin can add a removal step on some Android versions, but a normal app cannot make itself undeletable. Device owners retain Android recovery and uninstall controls.";
        if (has(q, "false positive", "news", "education", "medical", "article", "keyword"))
            return "VYRA now uses page-level text signals, explicit phrases and context hints. Generic words by themselves should not trigger a block. This heuristic reduces false positives but cannot guarantee perfect classification.";
        if (has(q, "focus", "timer", "session"))
            return "Open Focus to start a timed session or an open-ended Long-term Journey. App enforcement requires selected apps and the Accessibility service to be enabled.";
        if (has(q, "setting", "permission", "help"))
            return "Use Settings for reminders, Accessibility permission, optional Device Admin and privacy information. Android Settings always remains available to revoke permissions or uninstall the app.";
        return "I can help with Focus Journey, app protection, text scanning, privacy, games, permissions and uninstall limits. Try asking about one of those topics.";
    }

    private boolean has(String text, String... terms) {
        for (String term : terms) if (text.contains(term)) return true;
        return false;
    }

    private void addMessage(String value, boolean user) {
        TextView bubble = label(value, 13, user ? BG : WHITE, false);
        bubble.setPadding(dp(14), dp(12), dp(14), dp(12));
        bubble.setBackground(round(user ? TEAL : CARD, 16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(user ? dp(290) : -1, -2);
        lp.gravity = user ? Gravity.RIGHT : Gravity.LEFT;
        lp.topMargin = dp(8); lp.bottomMargin = dp(4);
        messages.addView(bubble, lp);
        scroll.post(() -> scroll.fullScroll(ScrollView.FOCUS_DOWN));
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private GradientDrawable round(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private GradientDrawable gradient(int[] colors, int radius) { GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors); d.setCornerRadius(dp(radius)); return d; }
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
}
