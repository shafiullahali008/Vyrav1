# Build VYRA 4.2.2 in GitHub Actions

1. Remove or disable previous VYRA build workflows, especially `.github/workflows/android.yml`, so an old workflow is not run alongside the new one.
2. Upload `VYRA-Android-4.2.2-Audit-Fix.zip` to the repository root.
3. Create `.github/workflows/vyra-android-build.yml` from the supplied `vyra-android-build.yml` file.
4. Commit both files to the `main` branch, or run **VYRA Android Build** from Actions.
5. Download `VYRA-Android-APK` after `assembleDebug` succeeds.
6. If assembly fails, download `VYRA-Build-Logs` and read `vyra-assemble.log` for the first Gradle error.

## Build configuration

- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- JDK: 17
- Android SDK Platform: 35
- Android Build Tools: 35.0.0
- The archive has a top-level `VYRA/` project folder.
- The application ID remains `com.nexas.safe`.
- The app version is 4.2.2 (versionCode 17).

APK assembly and unit tests run in separate steps. Unit-test failure is reported but does not block uploading an APK that has already assembled successfully. An APK compilation failure still correctly fails the build and uploads diagnostic logs.
