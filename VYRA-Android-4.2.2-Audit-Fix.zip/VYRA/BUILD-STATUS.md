# VYRA 4.2.2 — Source audit and build pipeline

## Source revision
- Android app versionName: 4.2.2
- Android app versionCode: 17
- Application ID remains `com.nexas.safe`.
- Existing app features, privacy labels, filtering keywords, image-classifier code, visual-capture consent flow, branding assets and gameplay code are retained.
- Gradle memory settings are conservative for hosted CI runners.
- Redundant embedded workflow copies have been removed. One reference workflow remains at `ci/vyra-android-build.yml`.

## Static checks performed
- ZIP archive integrity check.
- XML parsing for manifest and all resource XML files.
- Java source syntax scan using the available JDK; no Java syntax diagnostics were found. Android SDK symbols could not be fully type-checked locally because `android.jar` is not installed.
- Resource references and manifest component declarations checked against project files.
- The actual `ContextAwareTextClassifierTest` cases were executed using a local minimal JUnit-compatible runner; all cases passed.
- Workflow YAML syntax and required file/path references checked.

## CI behaviour
- GitHub Actions uses JDK 17, Gradle 8.9, Android SDK Platform 35 and Build Tools 35.0.0.
- APK assembly (`assembleDebug`) runs separately from unit tests.
- Unit-test failure is recorded but does not block uploading a successfully assembled APK.
- Assembly and test logs are uploaded as `VYRA-Build-Logs` for diagnosis.

## Verification boundary
A complete Android Gradle build and physical-device test have not been performed in this environment because the Android SDK and Gradle distribution are unavailable here and outbound network resolution is disabled. Do not treat static checks as proof of an error-free APK. The GitHub Actions build is the definitive compile check.
